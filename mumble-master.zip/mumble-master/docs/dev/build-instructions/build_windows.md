# Building on Windows 

On Windows we only support [static builds](build_static.md).

Make sure to [install Visual Studio](setup_visual_studio.md) in order to be able to compile the necessary code.
