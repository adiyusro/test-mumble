These flag icons were extracted from the Emoji One
Git repository, found at

    https://github.com/Ranks/emojione

at commit

    0aad7f9f7969f0187e4f50d12fdc113541a34ac3 (tag 2.2.7)

using the script found in the Mumble source tree
found at

    scripts/extract-emojione-flags.py
