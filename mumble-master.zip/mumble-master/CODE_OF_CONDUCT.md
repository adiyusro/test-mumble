# Contributor Code of Conduct

We expect everyone participating in the development and/or discussions related to the Mumble project to use a friendly tone, regardless of whom the conversation partner might be.

We explicitly state that we do not care about (nor do we accept discrimination based on) things like (including but not limited to) gender, country of origin and/or skin color.

Additionally we expect everyone to be able to voice and receive objective criticism.
